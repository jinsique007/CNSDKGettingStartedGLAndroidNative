var core_8interlacer_8h =
[
    [ "leia_interlacer_init_configuration_alloc", "group__interlacer.html#gad064fdd2334fb1eb993935f0398f8f7f", null ],
    [ "leia_interlacer_init_configuration_set_is_protected", "group__interlacer.html#ga22769f1ba68e9bdb3b1a2c0a7afd31d6", null ],
    [ "leia_interlacer_init_configuration_set_use_atlas_for_views", "group__interlacer.html#ga5064d013377f9b52fff50981dbd15326", null ],
    [ "leia_interlacer_init_configuration_free", "group__interlacer.html#gad37c7773fa126c37951731e3af7c8c1d", null ],
    [ "leia_interlacer_set_enable_user_matrix", "group__interlacer.html#ga0f6857ec15be5c5db46610ec67f0033d", null ],
    [ "leia_interlacer_get_user_matrix", "group__interlacer.html#gac8afc95c265cf5db85037d1375ba268c", null ],
    [ "leia_interlacer_set_user_matrix", "group__interlacer.html#gade151ae13510e434c212a18f4e6ca08b", null ]
];