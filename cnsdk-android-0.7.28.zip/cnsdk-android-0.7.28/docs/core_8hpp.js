var core_8hpp =
[
    [ "CoreInitConfiguration", "classleia_1_1sdk_1_1_core_init_configuration.html", "classleia_1_1sdk_1_1_core_init_configuration" ],
    [ "Core", "classleia_1_1sdk_1_1_core.html", "classleia_1_1sdk_1_1_core" ],
    [ "LEIA_WRAPPER_DISABLE_EXCEPTION", "group__core.html#gaf338ef451292dfb9a805edbc871e9d05", null ],
    [ "Vector3", "core_8hpp.html#a871ce7ffd09c1b955f4c2d8d5d59c5e9", null ],
    [ "Vector4", "core_8hpp.html#abe10c46c3d835ccd5c627ef94870987a", null ],
    [ "Mat4", "core_8hpp.html#ae4ed65ca488a8b2fff2682b30828149a", null ],
    [ "FloatSlice", "core_8hpp.html#a4b2aa456da7e9e0bb3b544bb4c1a9fcd", null ],
    [ "ConstFloatSlice", "core_8hpp.html#a890ec4580674a739be44397e1c0cda9f", null ],
    [ "SharedCameraSink", "core_8hpp.html#a3f2f175d6a152791018ba96bb92c338f", null ],
    [ "Config", "core_8hpp.html#a4daad15aaf66677863ba54b2a8ada0e6", null ],
    [ "CoreAndroidHandleType", "core_8hpp.html#a87dca1476eabb642ff5326d52386d1a2", null ],
    [ "FaceTrackingFrameListener", "core_8hpp.html#a7ecf079ea69b24d0ddf4ae74db326961", null ],
    [ "FaceTrackingFrame", "core_8hpp.html#a58e2750379ad2316d1f119251f4bed05", null ],
    [ "ToSlice", "core_8hpp.html#a7d9743372905c80d4b9d8745e64f8e58", null ],
    [ "ToSlice", "core_8hpp.html#af69c4cf03da49f3e695eae425853f2be", null ],
    [ "ToConstSlice", "core_8hpp.html#a4135db458e192b6ef8e45c7a852dfe6f", null ],
    [ "ToConstSlice", "core_8hpp.html#a31fe08e10ccadab49efb317d11a3d74c", null ],
    [ "IsFaceTrackingRuntimeSupported", "core_8hpp.html#a11d967a3f89f935cc9fc5117960097b5", null ]
];