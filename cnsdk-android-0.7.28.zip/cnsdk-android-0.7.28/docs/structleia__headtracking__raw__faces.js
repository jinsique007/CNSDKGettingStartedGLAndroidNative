var structleia__headtracking__raw__faces =
[
    [ "numFaces", "structleia__headtracking__raw__faces.html#a523d3dc0299fc8921db1c26cc908f084", null ],
    [ "faces", "structleia__headtracking__raw__faces.html#a8789f451bbc3b13b8f3a5cb3a3f1376e", null ]
];