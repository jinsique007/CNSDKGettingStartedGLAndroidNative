var core_8event_8h =
[
    [ "leia_core_event_code", "core_8event_8h.html#a9af580b94adef7f75592e701946604b3", [
      [ "LEIA_CORE_EVENT_DID_INITIALIZE", "core_8event_8h.html#a9af580b94adef7f75592e701946604b3abf2869c11ecc9a226bc2bf393bffb579", null ],
      [ "_LEIA_CORE_EVENT_CODE_MAKE_ENUM_32BIT", "core_8event_8h.html#a9af580b94adef7f75592e701946604b3a5eda74edff953fa93e4242d354146b95", null ]
    ] ]
];