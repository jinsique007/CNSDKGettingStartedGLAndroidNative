var structleia__interlacer__debug__menu__configuration =
[
    [ "gui", "structleia__interlacer__debug__menu__configuration.html#a8611a6b9f477359b270734ec55206215", null ],
    [ "customGui", "structleia__interlacer__debug__menu__configuration.html#a9a6f5e1b8994519e65269c6e90c2ccab", null ],
    [ "userData", "structleia__interlacer__debug__menu__configuration.html#a2e294dd14122c554baa0665072b4ca7a", null ]
];