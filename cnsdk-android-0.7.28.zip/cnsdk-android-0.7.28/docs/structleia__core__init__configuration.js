var structleia__core__init__configuration =
[
    [ "leia_core_init_configuration_set_enable_validation", "group__core.html#ga5d3f1be139d6cb73629d0f6741db3ecb", null ],
    [ "leia_core_init_configuration_set_platform_android_handle", "group__core.html#gaff177cb74076ed81839bb26b8b9d78e4", null ],
    [ "leia_core_init_configuration_set_platform_android_java_vm", "group__core.html#gab256b7ea7dfe7f9bbf7b8f1b9785b9e8", null ],
    [ "leia_core_init_configuration_set_platform_log_level", "group__core.html#gadec5c5c0e2c9b950bb97c6b24a08cf02", null ],
    [ "leia_core_init_configuration_set_face_tracking_shared_camera_sink", "group__core.html#ga726138064526558abdf26dd715d70d68", null ],
    [ "leia_core_init_configuration_set_face_tracking_runtime", "group__core.html#gae587f45b05b30dc2e8f4271469f51086", null ],
    [ "leia_core_init_configuration_set_face_tracking_enable", "group__core.html#ga22e27e29b739bcf2931717d0cb81909b", null ],
    [ "leia_core_init_configuration_set_face_tracking_start", "group__core.html#gaaf50cc0a44abc74fd9ca86a20cecb08b", null ],
    [ "leia_core_init_configuration_set_face_tracking_check_permission", "group__core.html#ga114cdcbf8f63029cf70d6512899a7d42", null ],
    [ "leia_core_init_configuration_set_face_tracking_permission_dialog_kill_process", "group__core.html#ga8fbbf291f33b0934337ff36d9d83c859", null ],
    [ "leia_core_init_configuration_set_face_tracking_server_log_level", "group__core.html#ga08a8e15f6dd95d8c231cdecd40e0698b", null ],
    [ "leia_core_init_configuration_set_hint", "group__core.html#gab80664390f1a2a4846d8601d6aaa7643", null ],
    [ "leia_core_init_configuration_free", "group__core.html#ga86e44e0cb0057691fd0b48c5ae6204dd", null ],
    [ "leia_core_init_configuration_alloc", "group__core.html#ga3aed4b7719f81d677d06f2c763f7fbee", null ]
];