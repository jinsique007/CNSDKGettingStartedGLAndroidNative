var types_8hpp =
[
    [ "Timestamp", "types_8hpp.html#a5d46d2c42834484dfe057302cd3950a2", null ],
    [ "TimestampSpace", "types_8hpp.html#a61b34ccc6f85d069bd4807a297f7c958", null ],
    [ "ImageDesc", "types_8hpp.html#ae132c5efaade52bc868a0c29e2ea4c6e", null ],
    [ "CameraIntrinsics", "types_8hpp.html#ad6349d79f8844a569cf0d772c81fe11e", null ],
    [ "FaceDetectorBackend", "types_8hpp.html#af22c51fbae7d6d9390e5820a38646bad", null ],
    [ "FaceDetectorInputType", "types_8hpp.html#a901164e733020444a1f12fc8bfe674b2", null ],
    [ "FaceDetectorConfig", "types_8hpp.html#a57b25746a254c9f927fcc4db7e7255ba", null ],
    [ "SourceLocation", "types_8hpp.html#a69d7dec3e8bac3459e105aeef249dc6f", null ],
    [ "ToStr", "types_8hpp.html#a574dc72dd1cf2a66346da4e654acc2d9", null ],
    [ "ToUiStr", "types_8hpp.html#ac381c9fb82cc50fd44f936debacaf4af", null ],
    [ "ToStr", "types_8hpp.html#a6ee23674123a353c28a99195fc87f9ab", null ],
    [ "ToUiStr", "types_8hpp.html#a93ba78c06e1383a651acbc3495d1bc26", null ]
];