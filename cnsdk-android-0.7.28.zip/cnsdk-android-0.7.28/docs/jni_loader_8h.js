var jni_loader_8h =
[
    [ "leia_jni_init_native_app", "jni_loader_8h.html#a337145f1ff921a4344f0f30a2c6054f4", null ],
    [ "leia_jni_deinit_native_app", "jni_loader_8h.html#aa3dc8bc04cc2c827e21f4978c60db01b", null ],
    [ "leia_jni_on_load", "jni_loader_8h.html#a9846fab5c8b1d420a3940e7c946f7544", null ],
    [ "leia_jni_on_unload", "jni_loader_8h.html#a0f0ccd0897120058e54609df98283a05", null ],
    [ "leia_jni_is_initialized", "jni_loader_8h.html#ad833cbee92888879452b681cebbc9319", null ],
    [ "leia_jni_get_java_vm", "jni_loader_8h.html#aa7ee6a0532efa6ef370e0471c471434e", null ]
];