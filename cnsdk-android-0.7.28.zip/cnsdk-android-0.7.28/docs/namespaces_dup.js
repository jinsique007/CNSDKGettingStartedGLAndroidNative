var namespaces_dup =
[
    [ "leia", "namespaceleia.html", "namespaceleia" ]
];