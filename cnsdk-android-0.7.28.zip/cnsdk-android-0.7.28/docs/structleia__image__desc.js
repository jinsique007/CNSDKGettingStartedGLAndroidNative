var structleia__image__desc =
[
    [ "data", "structleia__image__desc.html#a96db82e580e46e24e2b39dd6c5bf7c21", null ],
    [ "width", "structleia__image__desc.html#a395d15e7c2b09961c1bfd1da6179b64c", null ],
    [ "height", "structleia__image__desc.html#a5d8006e753a3e76ff637a4e092bbed71", null ],
    [ "rotation", "structleia__image__desc.html#adefca2f0dfb1983c9dc09e4d89499741", null ]
];