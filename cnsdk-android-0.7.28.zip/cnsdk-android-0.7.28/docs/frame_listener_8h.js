var frame_listener_8h =
[
    [ "leia_headtracking_frame_listener", "structleia__headtracking__frame__listener.html", "structleia__headtracking__frame__listener" ],
    [ "leia_headtracking_on_frame_cb", "frame_listener_8h.html#afe71baf6ded6aa97ad082e762750f402", null ]
];