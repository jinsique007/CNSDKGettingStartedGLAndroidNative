var structleia__headtracking__raw__face =
[
    [ "eyePoints", "structleia__headtracking__raw__face.html#a2543907435ba6a71f97083bbe04aab9b", null ],
    [ "trackingPoint", "structleia__headtracking__raw__face.html#acfb3d223d93af7cd7d98491c7388ac6f", null ],
    [ "detectedFaceIndex", "structleia__headtracking__raw__face.html#ad9546ec5f1907eb528f46692b8edf125", null ]
];