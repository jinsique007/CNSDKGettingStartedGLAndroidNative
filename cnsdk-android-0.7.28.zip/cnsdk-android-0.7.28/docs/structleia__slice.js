var structleia__slice =
[
    [ "data", "structleia__slice.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "length", "structleia__slice.html#a5ae5048776b1de2d7dce124f78dc300f", null ]
];