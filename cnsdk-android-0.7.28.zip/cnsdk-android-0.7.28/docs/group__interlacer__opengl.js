var group__interlacer__opengl =
[
    [ "leia", "namespaceleia.html", null ],
    [ "leia_interlacer_opengl_initialize", "group__interlacer__opengl.html#ga8e96cd6be3f12a5303454e375e4c8fb7", null ],
    [ "leia_interlacer_opengl_do_post_process", "group__interlacer__opengl.html#gac5dcf10270797e9b3d5aa711f95cf8f7", null ],
    [ "leia_interlacer_opengl_do_post_process_picture", "group__interlacer__opengl.html#ga75d483ce53d2d5ada23734dc4d3ee3c5", null ],
    [ "leia_interlacer_opengl_do_post_process_video", "group__interlacer__opengl.html#ga053903b94e1049765c20814c190a8e0e", null ],
    [ "leia_interlacer_opengl_get_render_target_for_view", "group__interlacer__opengl.html#gaa3a43480b9c25df48ea84e3cfda6f47f", null ],
    [ "leia_interlacer_opengl_get_render_target_for_view_ex", "group__interlacer__opengl.html#ga5c3e7d45319ce37e689df6ca18018796", null ],
    [ "leia_interlacer_opengl_set_interlace_view_texture_atlas", "group__interlacer__opengl.html#gac5ed8c70006dd5f00bb9c9d8faba9a72", null ],
    [ "leia_interlacer_opengl_set_output_render_target", "group__interlacer__opengl.html#gaff361786b6462bb7b6972f1de1217263", null ],
    [ "leia_interlacer_opengl_set_view_for_texture_array", "group__interlacer__opengl.html#gac79c4f22913b37d0f4abe585c90de076", null ],
    [ "leia_interlacer_opengl_set_view_texture_id", "group__interlacer__opengl.html#ga246f62585919487813b9c036532bcc7b", null ]
];