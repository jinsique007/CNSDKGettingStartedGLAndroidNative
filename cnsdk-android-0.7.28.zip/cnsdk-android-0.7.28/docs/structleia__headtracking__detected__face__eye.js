var structleia__headtracking__detected__face__eye =
[
    [ "imageCoord", "structleia__headtracking__detected__face__eye.html#ad018f5252293bedd29bfa7ac59cf6141", null ],
    [ "depth", "structleia__headtracking__detected__face__eye.html#a845896541a0621f5fbd11f0d115ce463", null ]
];