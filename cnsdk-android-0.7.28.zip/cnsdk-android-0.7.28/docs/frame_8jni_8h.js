var frame_8jni_8h =
[
    [ "leia_headtracking_frame_to_java", "frame_8jni_8h.html#a68a53c717c6a3fb1f0cffc2da324f153", null ],
    [ "NONOWNING", "frame_8jni_8h.html#a2ede8b8dbf891243c16d09578fe4fa00", null ],
    [ "jobject", "frame_8jni_8h.html#a69aa717b9e4a8065d1f96e338a5048b5", null ]
];