var shared_camera_sink_8h =
[
    [ "leia_shared_camera_sink_alloc", "shared_camera_sink_8h.html#a86c1df00f734401b2c4c527b0c43c9e2", null ],
    [ "leia_shared_camera_sink_free", "shared_camera_sink_8h.html#a64544e1c145351484c55db8206613661", null ],
    [ "leia_shared_camera_sink_is_valid", "shared_camera_sink_8h.html#a39fb4614d41f98921166b139a9240efb", null ],
    [ "leia_shared_camera_sink_on_image", "shared_camera_sink_8h.html#a408971ae56617beabafd0f34235413c3", null ],
    [ "leia_shared_camera_sink_on_intrinsics_change", "shared_camera_sink_8h.html#a200746387f26dcd3092a7d4d2da7c3be", null ],
    [ "leia_shared_camera_sink_on_lux_change", "shared_camera_sink_8h.html#a789886b408e3ee173c1dd2cc9e6e431f", null ]
];