var structleia__event__log =
[
    [ "message", "structleia__event__log.html#a254bf0858da09c96a48daf64404eb4f8", null ],
    [ "level", "structleia__event__log.html#af921aaa7ff503501f0b16abcafb122cc", null ]
];