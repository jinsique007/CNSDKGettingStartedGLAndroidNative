var slice_8h =
[
    [ "leia_float_slice", "structleia__float__slice.html", "structleia__float__slice" ],
    [ "leia_const_float_slice", "structleia__const__float__slice.html", "structleia__const__float__slice" ],
    [ "leia_slice", "structleia__slice.html", "structleia__slice" ],
    [ "LEIA_FLOAT_SLICE", "slice_8h.html#a87b894268916eaa6044e23d385f70af0", null ],
    [ "LEIA_CONST_FLOAT_SLICE", "slice_8h.html#ab11b02dd2b8e9b4db1ad27bfb2e7dd1a", null ]
];