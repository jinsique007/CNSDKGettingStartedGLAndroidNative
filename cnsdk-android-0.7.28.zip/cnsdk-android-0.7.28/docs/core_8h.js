var core_8h =
[
    [ "LEIA_CORE_HINT_USE_OLD_RENDERER", "group__core.html#ga0485c62df02c7553011e421c409eacbf", null ],
    [ "leia_core_android_handle_type", "group__core.html#gac82e4f2968c7ab993f12d3d2a513ca26", [
      [ "LEIA_CORE_ANDROID_HANDLE_APP", "group__core.html#ggac82e4f2968c7ab993f12d3d2a513ca26ab8b968a3c9260302bcd9f81fe7bb4871", null ],
      [ "LEIA_CORE_ANDROID_HANDLE_ACTIVITY", "group__core.html#ggac82e4f2968c7ab993f12d3d2a513ca26a44619af509893122308f297cec013c12", null ],
      [ "LEIA_CORE_ANDROID_HANDLE_CONTEXT", "group__core.html#ggac82e4f2968c7ab993f12d3d2a513ca26ae9dc652f6eae9478357cc4c50f53961e", null ],
      [ "_LEIA_CORE_ANDROID_HANDLE_MAKE_ENUM_32BIT", "group__core.html#ggac82e4f2968c7ab993f12d3d2a513ca26a6127cdc5ea7c8f63104afa25a912fa0b", null ]
    ] ]
];