var structleia__vector2d =
[
    [ "x", "structleia__vector2d.html#af88b946fb90d5f08b5fb740c70e98c10", null ],
    [ "y", "structleia__vector2d.html#ab927965981178aa1fba979a37168db2a", null ]
];