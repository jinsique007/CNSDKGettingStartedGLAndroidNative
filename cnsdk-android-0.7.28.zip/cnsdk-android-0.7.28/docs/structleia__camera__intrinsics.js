var structleia__camera__intrinsics =
[
    [ "width", "structleia__camera__intrinsics.html#a395d15e7c2b09961c1bfd1da6179b64c", null ],
    [ "height", "structleia__camera__intrinsics.html#a5d8006e753a3e76ff637a4e092bbed71", null ],
    [ "ppx", "structleia__camera__intrinsics.html#a9815f1f43eb0cc619c45deb604562ae0", null ],
    [ "ppy", "structleia__camera__intrinsics.html#a989d8e72ccf2c834e8be99c17cb204b4", null ],
    [ "fx", "structleia__camera__intrinsics.html#a3ebaeeb2af54ad4cb13f0fb25c78a639", null ],
    [ "fy", "structleia__camera__intrinsics.html#a49e77bf673d6b57520e348f4e34df5e3", null ],
    [ "distortionCoeffs", "structleia__camera__intrinsics.html#aad0175e51259dd9da4af7dc8f4dda8e6", null ],
    [ "isMirrored", "structleia__camera__intrinsics.html#a7bf4bc97c27d3932acc91b96ebc3a0b8", null ]
];