var searchData=
[
  ['cnsdk_5fmajor_5fversion_0',['CNSDK_MAJOR_VERSION',['../version_8h.html#a9926f3a063a23b9bbbb409c3dcc31607',1,'version.h']]],
  ['cnsdk_5fminor_5fversion_1',['CNSDK_MINOR_VERSION',['../version_8h.html#a8762cb257a2a9a93963f8e45ffdd825c',1,'version.h']]],
  ['cnsdk_5fpatch_5fversion_2',['CNSDK_PATCH_VERSION',['../version_8h.html#a2beea5a2a6bf15fc1a36c94a0f453162',1,'version.h']]],
  ['cnsdk_5fversion_3',['CNSDK_VERSION',['../version_8h.html#af4ec833d6d283013bbae6067e586b963',1,'version.h']]]
];
