var searchData=
[
  ['imgui_5fapi_0',['IMGUI_API',['../config_8hpp.html#a43829975e84e45d1149597467a14bbf5',1,'config.hpp']]]
];
