var searchData=
[
  ['timestamp_0',['Timestamp',['../namespaceleia.html#a5d46d2c42834484dfe057302cd3950a2',1,'leia']]],
  ['timestampspace_1',['TimestampSpace',['../namespaceleia.html#a61b34ccc6f85d069bd4807a297f7c958',1,'leia']]]
];
