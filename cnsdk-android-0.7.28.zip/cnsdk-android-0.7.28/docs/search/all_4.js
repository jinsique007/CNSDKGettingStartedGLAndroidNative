var searchData=
[
  ['d3d11_0',['d3d11',['../structleia__interlacer__gui__configuration.html#a36012a74401121be689cfce38f7dfa2c',1,'leia_interlacer_gui_configuration']]],
  ['d3d11_20interlacer_1',['D3D11 Interlacer',['../group__interlacer__d3d11.html',1,'']]],
  ['d3d12_2',['d3d12',['../structleia__interlacer__gui__configuration.html#a77a7727a52c71f99f008ce761bfb7daf',1,'leia_interlacer_gui_configuration']]],
  ['d3d12_20interlacer_3',['D3D12 Interlacer',['../group__interlacer__d3d12.html',1,'']]],
  ['d_5fover_5fn_4',['d_over_n',['../structleia__device__config.html#a8d137bf64604fe3b16f3609423b47c5c',1,'leia_device_config']]],
  ['data_5',['data',['../structleia__asset__manager__buffer.html#a91a70b77df95bd8b0830b49a094c2acb',1,'leia_asset_manager_buffer::data'],['../structleia__float__slice.html#a57ba9c584cf7756552b7d4370e93395f',1,'leia_float_slice::data'],['../structleia__const__float__slice.html#a90f4df5a48f55b281e1b7293e9a4509c',1,'leia_const_float_slice::data'],['../structleia__slice.html#a735984d41155bc1032e09bece8f8d66d',1,'leia_slice::data'],['../structleia__image__desc.html#a96db82e580e46e24e2b39dd6c5bf7c21',1,'leia_image_desc::data']]],
  ['defaulteventhandler_6',['DefaultEventHandler',['../namespaceleia.html#a3ba5430e5ac97d8a1ddc6bdef092889d',1,'leia']]],
  ['defines_2eh_7',['defines.h',['../defines_8h.html',1,'']]],
  ['depth_8',['depth',['../structleia__headtracking__detected__face__eye.html#a845896541a0621f5fbd11f0d115ce463',1,'leia_headtracking_detected_face_eye']]],
  ['descriptorpool_9',['descriptorPool',['../structleia__interlacer__gui__configuration.html#ab3d7cf82d736cba3c1eae31ffeadf68f',1,'leia_interlacer_gui_configuration']]],
  ['detectedfaceindex_10',['detectedFaceIndex',['../structleia__headtracking__raw__face.html#ad9546ec5f1907eb528f46692b8edf125',1,'leia_headtracking_raw_face']]],
  ['device_11',['device',['../structleia__interlacer__gui__configuration.html#abd28c0efe479c17c1476917841e26ea8',1,'leia_interlacer_gui_configuration']]],
  ['devicecbvsrvheap_12',['deviceCbvSrvHeap',['../structleia__interlacer__gui__configuration.html#a80915f53b7953146354a02b06364cf04',1,'leia_interlacer_gui_configuration']]],
  ['devicecontext_13',['deviceContext',['../structleia__interlacer__gui__configuration.html#af643ce617f0e2e8aec271ea106b61f38',1,'leia_interlacer_gui_configuration']]],
  ['displaysizeinmm_14',['displaySizeInMm',['../structleia__device__config.html#ac7e81de586c485d64ae20d1d8540bc49',1,'leia_device_config']]],
  ['distortioncoeffs_15',['distortionCoeffs',['../structleia__camera__intrinsics.html#aad0175e51259dd9da4af7dc8f4dda8e6',1,'leia_camera_intrinsics']]],
  ['dopostprocess_16',['DoPostProcess',['../classleia_1_1sdk_1_1_interlacer_d3_d11.html#a2d239e95b6b96afc84fd109eb4251b41',1,'leia::sdk::InterlacerD3D11::DoPostProcess()'],['../classleia_1_1sdk_1_1_interlacer_d3_d12.html#afc69e9e56660ad55a88ea780a353a043',1,'leia::sdk::InterlacerD3D12::DoPostProcess()'],['../classleia_1_1sdk_1_1_interlacer_open_g_l.html#a3147d32d74da6c255ea9eb75b9dcd1e6',1,'leia::sdk::InterlacerOpenGL::DoPostProcess()'],['../classleia_1_1sdk_1_1_interlacer_vulkan.html#a24ebaede5dc1d1a8c60878691a4e7145',1,'leia::sdk::InterlacerVulkan::DoPostProcess()']]],
  ['dopostprocesspicture_17',['DoPostProcessPicture',['../classleia_1_1sdk_1_1_interlacer_d3_d11.html#a6ddf857f9478a2fa45cb26fc4ad3a014',1,'leia::sdk::InterlacerD3D11::DoPostProcessPicture()'],['../classleia_1_1sdk_1_1_interlacer_d3_d12.html#a8ca9400b3ed38739ad6313b169864e35',1,'leia::sdk::InterlacerD3D12::DoPostProcessPicture()'],['../classleia_1_1sdk_1_1_interlacer_open_g_l.html#a8470a8c5d84b9528d1b1f15be0722f2a',1,'leia::sdk::InterlacerOpenGL::DoPostProcessPicture()'],['../classleia_1_1sdk_1_1_interlacer_vulkan.html#a9c0707df610d5c88bbad14a20a5b8473',1,'leia::sdk::InterlacerVulkan::DoPostProcessPicture()']]],
  ['dopostprocessvideo_18',['DoPostProcessVideo',['../classleia_1_1sdk_1_1_interlacer_open_g_l.html#a9fcd49bf32276256851e34adc8643620',1,'leia::sdk::InterlacerOpenGL']]],
  ['dotpitchinmm_19',['dotPitchInMM',['../structleia__device__config.html#ae582e238cb2a84c699b615123c1589ca',1,'leia_device_config']]],
  ['dummy_20',['dummy',['../structleia__asset__manager__resolve__context.html#a2bc054607a1d5d077801e7a89bc1e2e2',1,'leia_asset_manager_resolve_context']]]
];
