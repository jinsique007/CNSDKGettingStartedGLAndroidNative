var searchData=
[
  ['jobject_0',['jobject',['../frame_8jni_8h.html#a69aa717b9e4a8065d1f96e338a5048b5',1,'frame.jni.h']]],
  ['jumpflag_1',['jumpFlag',['../structleia__headtracking__tracking__result.html#a85c3cc94b68a21d4563017b4e0244829',1,'leia_headtracking_tracking_result']]]
];
