var searchData=
[
  ['nonowning_0',['NONOWNING',['../defines_8h.html#ae154d5ab9b8400379c22361f6d7acad0',1,'defines.h']]]
];
