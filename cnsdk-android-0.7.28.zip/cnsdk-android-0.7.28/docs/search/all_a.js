var searchData=
[
  ['javavm_0',['JavaVM',['../jni_types_8h.html#abc5c833ca98abdc33d0567b174e2e132',1,'jniTypes.h']]],
  ['jint_1',['jint',['../jni_types_8h.html#a36d2d2d6848d7f576b7f8875f95efd1e',1,'jniTypes.h']]],
  ['jnienv_2',['JNIEnv',['../jni_types_8h.html#ade02b8c45188da2bfcfa8072214d0e1c',1,'jniTypes.h']]],
  ['jniloader_2eh_3',['jniLoader.h',['../jni_loader_8h.html',1,'']]],
  ['jnitypes_2eh_4',['jniTypes.h',['../jni_types_8h.html',1,'']]],
  ['jobject_5',['jobject',['../jni_types_8h.html#a24647d2a2f02c39f6338c2c6ce4c1004',1,'jobject:&#160;jniTypes.h'],['../frame_8jni_8h.html#a69aa717b9e4a8065d1f96e338a5048b5',1,'jobject:&#160;frame.jni.h']]],
  ['jumpflag_6',['jumpFlag',['../structleia__headtracking__tracking__result.html#a85c3cc94b68a21d4563017b4e0244829',1,'leia_headtracking_tracking_result']]]
];
