var searchData=
[
  ['toconstslice_0',['ToConstSlice',['../namespaceleia.html#a4135db458e192b6ef8e45c7a852dfe6f',1,'leia::ToConstSlice(leia_vector3 const *v)'],['../namespaceleia.html#a31fe08e10ccadab49efb317d11a3d74c',1,'leia::ToConstSlice(Mat4 *v)']]],
  ['toslice_1',['ToSlice',['../namespaceleia.html#a7d9743372905c80d4b9d8745e64f8e58',1,'leia::ToSlice(Vector3 *v)'],['../namespaceleia.html#af69c4cf03da49f3e695eae425853f2be',1,'leia::ToSlice(Mat4 *v)']]],
  ['tostr_2',['ToStr',['../namespaceleia.html#a574dc72dd1cf2a66346da4e654acc2d9',1,'leia::ToStr(FaceDetectorBackend backend)'],['../namespaceleia.html#a6ee23674123a353c28a99195fc87f9ab',1,'leia::ToStr(FaceDetectorInputType inputType)']]],
  ['touistr_3',['ToUiStr',['../namespaceleia.html#ac381c9fb82cc50fd44f936debacaf4af',1,'leia::ToUiStr(FaceDetectorBackend backend)'],['../namespaceleia.html#a93ba78c06e1383a651acbc3495d1bc26',1,'leia::ToUiStr(FaceDetectorInputType inputType)'],['../namespaceleia.html#a31037bf8465d6bce27f43ff423fa04b7',1,'leia::ToUiStr(FaceTrackingRuntimeType faceTrackingRuntimeType)'],['../namespaceleia.html#a904f8df6c502e227096b7e38b599d70e',1,'leia::ToUiStr(InterlaceMode interlaceMode)'],['../namespaceleia.html#ad975b940880fd33b88c3e3f04a2ef1a4',1,'leia::ToUiStr(ShaderDebugMode shaderDebugMode)']]]
];
