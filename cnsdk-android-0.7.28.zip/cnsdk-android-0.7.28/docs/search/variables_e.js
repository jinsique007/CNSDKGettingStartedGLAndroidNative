var searchData=
[
  ['onsingleviewmodechange_0',['onSingleViewModeChange',['../structleia__interlacer__single__view__mode__listener.html#ace4a506b6089ad509c0b980f0cc02879',1,'leia_interlacer_single_view_mode_listener']]],
  ['overlay_1',['overlay',['../structleia__device__config.html#a89154628df2e8d87603055611ddae5e1',1,'leia_device_config']]]
];
