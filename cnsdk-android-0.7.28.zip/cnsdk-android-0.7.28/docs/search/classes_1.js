var searchData=
[
  ['core_0',['Core',['../classleia_1_1sdk_1_1_core.html',1,'leia::sdk']]],
  ['coreinitconfiguration_1',['CoreInitConfiguration',['../classleia_1_1sdk_1_1_core_init_configuration.html',1,'leia::sdk']]]
];
