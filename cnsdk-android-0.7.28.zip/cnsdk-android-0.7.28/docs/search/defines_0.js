var searchData=
[
  ['_5fleia_5fstringize_0',['_LEIA_STRINGIZE',['../defines_8h.html#a63c0765d76c688378749faa58e1fd735',1,'defines.h']]]
];
