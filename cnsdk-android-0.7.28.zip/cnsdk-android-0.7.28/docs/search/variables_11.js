var searchData=
[
  ['rawfaceindex_0',['rawFaceIndex',['../structleia__headtracking__face.html#a51dc17839177a2d076f0a426c5da3142',1,'leia_headtracking_face']]],
  ['renderpass_1',['renderPass',['../structleia__interlacer__gui__configuration.html#aa075be42575653e2ff975d553bf05203',1,'leia_interlacer_gui_configuration']]],
  ['rotation_2',['rotation',['../structleia__image__desc.html#adefca2f0dfb1983c9dc09e4d89499741',1,'leia_image_desc']]],
  ['rtvformat_3',['rtvFormat',['../structleia__interlacer__gui__configuration.html#a484bf74dacfad1b21b031e15198fd0d8',1,'leia_interlacer_gui_configuration']]]
];
