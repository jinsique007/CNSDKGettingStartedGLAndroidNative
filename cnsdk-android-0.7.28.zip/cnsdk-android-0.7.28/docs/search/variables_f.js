var searchData=
[
  ['p1_0',['p1',['../structleia__device__config.html#a37c96b33f506eef039e9bcfb6e591197',1,'leia_device_config']]],
  ['p2_1',['p2',['../structleia__device__config.html#aee2214de575f7c6752b0c76dcf1b7979',1,'leia_device_config']]],
  ['p_5fover_5fdu_2',['p_over_du',['../structleia__device__config.html#a8cb9b25b93c2b4af7b8dceeef0d90c18',1,'leia_device_config']]],
  ['p_5fover_5fdv_3',['p_over_dv',['../structleia__device__config.html#a46e3a4abef8fdda5aa4ed008b2355027',1,'leia_device_config']]],
  ['panelresolution_4',['panelResolution',['../structleia__device__config.html#a6dd887a9cc9a08cfe414d653d38ad516',1,'leia_device_config']]],
  ['payload_5',['payload',['../structleia__event__component.html#a40f7bdac227a665c6f751055f94af57f',1,'leia_event_component']]],
  ['phc_6',['phc',['../structleia__device__config.html#abb36892e4208a54482bef19bee687ed6',1,'leia_device_config']]],
  ['physicaldevice_7',['physicalDevice',['../structleia__interlacer__gui__configuration.html#a0a88baaed215cf4033826cfd0f579397',1,'leia_interlacer_gui_configuration']]],
  ['pipelinecache_8',['pipelineCache',['../structleia__interlacer__gui__configuration.html#a972a0396a5db1477d2be9a91f5f7dedf',1,'leia_interlacer_gui_configuration']]],
  ['point_9',['point',['../structleia__headtracking__face.html#a5d7996f088a1573f1b56ed6ac3f0f827',1,'leia_headtracking_face']]],
  ['pos_10',['pos',['../structleia__headtracking__moving__point.html#a2a529016ee03846e47ccf4fec7f263e3',1,'leia_headtracking_moving_point']]],
  ['poseangle_11',['poseAngle',['../structleia__headtracking__detected__face.html#a4d25a82a52534f20162af85aee6780b9',1,'leia_headtracking_detected_face']]],
  ['poseposition_12',['posePosition',['../structleia__headtracking__detected__face.html#a22a9f413a480ae2792d37365076233ec',1,'leia_headtracking_detected_face']]],
  ['ppx_13',['ppx',['../structleia__camera__intrinsics.html#a9815f1f43eb0cc619c45deb604562ae0',1,'leia_camera_intrinsics']]],
  ['ppy_14',['ppy',['../structleia__camera__intrinsics.html#a989d8e72ccf2c834e8be99c17cb204b4',1,'leia_camera_intrinsics']]]
];
