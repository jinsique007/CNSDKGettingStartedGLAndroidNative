var searchData=
[
  ['v_0',['v',['../structleia__event.html#ab6ba54c159129b751a87f4263ba268d7',1,'leia_event::v'],['../structleia__vector3.html#a9a1a1a00f1e45435cc3001b553000a21',1,'leia_vector3::v'],['../structleia__vector4.html#a557d2875124e0af14300c7f6e9a370bd',1,'leia_vector4::v']]],
  ['vel_1',['vel',['../structleia__headtracking__moving__point.html#ab19ddd00d8fe9dac8100a942e41dec4a',1,'leia_headtracking_moving_point']]],
  ['viewresolution_2',['viewResolution',['../structleia__device__config.html#a3f7019f7b105da8001b2bb0f5cc88ad1',1,'leia_device_config']]],
  ['vulkan_3',['vulkan',['../structleia__interlacer__gui__configuration.html#aded3f626dc1f9077a27dff217248a3be',1,'leia_interlacer_gui_configuration']]]
];
