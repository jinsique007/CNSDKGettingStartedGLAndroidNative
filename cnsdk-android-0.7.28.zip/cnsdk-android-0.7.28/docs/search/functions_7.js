var searchData=
[
  ['nonowning_0',['NONOWNING',['../frame_8jni_8h.html#a2ede8b8dbf891243c16d09578fe4fa00',1,'frame.jni.h']]]
];
