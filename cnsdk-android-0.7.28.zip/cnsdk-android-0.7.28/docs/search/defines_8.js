var searchData=
[
  ['owning_0',['OWNING',['../defines_8h.html#ad18bf199ec565ac3daf1a572e5ae6a7b',1,'defines.h']]]
];
