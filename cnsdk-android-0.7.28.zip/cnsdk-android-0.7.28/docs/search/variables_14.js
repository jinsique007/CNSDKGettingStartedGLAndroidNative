var searchData=
[
  ['userdata_0',['userData',['../structleia__interlacer__single__view__mode__listener.html#a2e294dd14122c554baa0665072b4ca7a',1,'leia_interlacer_single_view_mode_listener::userData'],['../structleia__interlacer__debug__menu__configuration.html#a2e294dd14122c554baa0665072b4ca7a',1,'leia_interlacer_debug_menu_configuration::userData']]]
];
