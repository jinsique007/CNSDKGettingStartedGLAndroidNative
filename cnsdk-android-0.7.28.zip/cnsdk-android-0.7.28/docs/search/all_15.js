var searchData=
[
  ['unregister_0',['Unregister',['../classleia_1_1_event_listener.html#a71c41f0f26923a528f47534e0cbb7d68',1,'leia::EventListener']]],
  ['useoldrenderer_1',['UseOldRenderer',['../classleia_1_1sdk_1_1_core_init_configuration.html#a6e6fcdcac96248aa9d314063f566b9c1',1,'leia::sdk::CoreInitConfiguration']]],
  ['userdata_2',['userData',['../structleia__interlacer__single__view__mode__listener.html#a2e294dd14122c554baa0665072b4ca7a',1,'leia_interlacer_single_view_mode_listener::userData'],['../structleia__interlacer__debug__menu__configuration.html#a2e294dd14122c554baa0665072b4ca7a',1,'leia_interlacer_debug_menu_configuration::userData']]]
];
