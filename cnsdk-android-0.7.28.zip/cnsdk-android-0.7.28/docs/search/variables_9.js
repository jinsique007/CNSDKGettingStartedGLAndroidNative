var searchData=
[
  ['id_0',['id',['../structleia__event__component.html#a86d453ff33ef64c0eea4f75d008116f4',1,'leia_event_component::id'],['../structleia__headtracking__detected__face.html#abaabdc509cdaba7df9f56c6c76f3ae19',1,'leia_headtracking_detected_face::id']]],
  ['imagecoord_1',['imageCoord',['../structleia__headtracking__detected__face__eye.html#ad018f5252293bedd29bfa7ac59cf6141',1,'leia_headtracking_detected_face_eye']]],
  ['imagecount_2',['imageCount',['../structleia__interlacer__gui__configuration.html#ab1b8b80864f18b43d1228c3df4f1241d',1,'leia_interlacer_gui_configuration']]],
  ['inputtype_3',['inputType',['../structleia__face__detector__config.html#adafb0bca2fe08bc75a9fadb0a0a3a765',1,'leia_face_detector_config']]],
  ['instance_4',['instance',['../structleia__interlacer__gui__configuration.html#ae1b90392cd257d16fd66a85bac1b08cd',1,'leia_interlacer_gui_configuration']]],
  ['ismirrored_5',['isMirrored',['../structleia__camera__intrinsics.html#a7bf4bc97c27d3932acc91b96ebc3a0b8',1,'leia_camera_intrinsics']]],
  ['isoverlaydeviceswitchable_6',['isOverlayDeviceSwitchable',['../structleia__device__config.html#a6ef4ec364fdb80f3aead8579bb884f27',1,'leia_device_config']]]
];
