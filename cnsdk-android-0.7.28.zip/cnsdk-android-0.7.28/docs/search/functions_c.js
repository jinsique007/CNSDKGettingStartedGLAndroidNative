var searchData=
[
  ['unregister_0',['Unregister',['../classleia_1_1_event_listener.html#a71c41f0f26923a528f47534e0cbb7d68',1,'leia::EventListener']]],
  ['useoldrenderer_1',['UseOldRenderer',['../classleia_1_1sdk_1_1_core_init_configuration.html#a6e6fcdcac96248aa9d314063f566b9c1',1,'leia::sdk::CoreInitConfiguration']]]
];
