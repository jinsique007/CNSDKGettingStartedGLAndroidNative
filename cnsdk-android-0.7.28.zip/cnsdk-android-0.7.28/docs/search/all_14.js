var searchData=
[
  ['theta_0',['theta',['../structleia__device__config.html#aadfc5c227ca658a29a59a0ce6fc15792',1,'leia_device_config']]],
  ['timestamp_1',['timestamp',['../structleia__headtracking__tracking__result.html#a450af1b278045fffef9c764cb90af310',1,'leia_headtracking_tracking_result']]],
  ['timestamp_2',['Timestamp',['../namespaceleia.html#a5d46d2c42834484dfe057302cd3950a2',1,'leia']]],
  ['timestampspace_3',['TimestampSpace',['../namespaceleia.html#a61b34ccc6f85d069bd4807a297f7c958',1,'leia']]],
  ['toconstslice_4',['ToConstSlice',['../namespaceleia.html#a4135db458e192b6ef8e45c7a852dfe6f',1,'leia::ToConstSlice(leia_vector3 const *v)'],['../namespaceleia.html#a31fe08e10ccadab49efb317d11a3d74c',1,'leia::ToConstSlice(Mat4 *v)']]],
  ['toslice_5',['ToSlice',['../namespaceleia.html#a7d9743372905c80d4b9d8745e64f8e58',1,'leia::ToSlice(Vector3 *v)'],['../namespaceleia.html#af69c4cf03da49f3e695eae425853f2be',1,'leia::ToSlice(Mat4 *v)']]],
  ['tostr_6',['ToStr',['../namespaceleia.html#a574dc72dd1cf2a66346da4e654acc2d9',1,'leia::ToStr(FaceDetectorBackend backend)'],['../namespaceleia.html#a6ee23674123a353c28a99195fc87f9ab',1,'leia::ToStr(FaceDetectorInputType inputType)']]],
  ['touistr_7',['ToUiStr',['../namespaceleia.html#ac381c9fb82cc50fd44f936debacaf4af',1,'leia::ToUiStr(FaceDetectorBackend backend)'],['../namespaceleia.html#a93ba78c06e1383a651acbc3495d1bc26',1,'leia::ToUiStr(FaceDetectorInputType inputType)'],['../namespaceleia.html#a31037bf8465d6bce27f43ff423fa04b7',1,'leia::ToUiStr(FaceTrackingRuntimeType faceTrackingRuntimeType)'],['../namespaceleia.html#a904f8df6c502e227096b7e38b599d70e',1,'leia::ToUiStr(InterlaceMode interlaceMode)'],['../namespaceleia.html#ad975b940880fd33b88c3e3f04a2ef1a4',1,'leia::ToUiStr(ShaderDebugMode shaderDebugMode)']]],
  ['trackingpoint_8',['trackingPoint',['../structleia__headtracking__raw__face.html#acfb3d223d93af7cd7d98491c7388ac6f',1,'leia_headtracking_raw_face']]],
  ['type_9',['type',['../structleia__event.html#a277b0b24e4b4a7276526ff94a5fcfb77',1,'leia_event']]],
  ['types_2efwd_2eh_10',['types.fwd.h',['../types_8fwd_8h.html',1,'']]],
  ['types_2eh_11',['types.h',['../common_2types_8h.html',1,'(Global Namespace)'],['../head_tracking_2common_2types_8h.html',1,'(Global Namespace)']]],
  ['types_2ehpp_12',['types.hpp',['../types_8hpp.html',1,'']]]
];
