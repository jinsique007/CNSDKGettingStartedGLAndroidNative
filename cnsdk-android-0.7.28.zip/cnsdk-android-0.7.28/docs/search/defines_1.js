var searchData=
[
  ['begin_5fcapi_5fdecl_0',['BEGIN_CAPI_DECL',['../defines_8h.html#af92e8a404827fb3c036bbb77ceb78b4a',1,'defines.h']]]
];
