var searchData=
[
  ['y_0',['y',['../structleia__vector2d.html#ab927965981178aa1fba979a37168db2a',1,'leia_vector2d::y'],['../structleia__vector3.html#aa4f0d3eebc3c443f9be81bf48561a217',1,'leia_vector3::y'],['../structleia__vector4.html#aa4f0d3eebc3c443f9be81bf48561a217',1,'leia_vector4::y']]]
];
