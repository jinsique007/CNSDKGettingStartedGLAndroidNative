var searchData=
[
  ['accelerationthreshold_0',['accelerationThreshold',['../structleia__device__config.html#ade83e02a54a0417b28fbf707c740b482',1,'leia_device_config']]],
  ['act_5fbeta_1',['act_beta',['../structleia__device__config.html#a8c8153494e7712be15fc6d2ddaebc134',1,'leia_device_config']]],
  ['act_5fgamma_2',['act_gamma',['../structleia__device__config.html#a3d716c95c903237b72a3bee22ae1ece8',1,'leia_device_config']]],
  ['act_5fsingletapcoef_3',['act_singleTapCoef',['../structleia__device__config.html#a401f64e0221e82d8ec50c008fb09d601',1,'leia_device_config']]],
  ['angle_4',['angle',['../structleia__headtracking__face.html#a95b2fc5dca3c574af547eed7d1d0a4a2',1,'leia_headtracking_face']]],
  ['apitimestamp_5',['apiTimestamp',['../structleia__headtracking__frame__profiling.html#a66f35b27d0fab8af77ae3adb4d3170dc',1,'leia_headtracking_frame_profiling']]]
];
