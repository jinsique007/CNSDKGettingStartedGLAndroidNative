var searchData=
[
  ['g_5fimguitls_0',['g_ImGuiTLS',['../config_8hpp.html#ae513721ecd2290f4d42dda251fbfa149',1,'config.hpp']]],
  ['graphicsapi_1',['graphicsAPI',['../structleia__interlacer__gui__configuration.html#a3bda2244ddef691bcf856fb55195b30d',1,'leia_interlacer_gui_configuration']]],
  ['gui_2',['gui',['../structleia__interlacer__debug__menu__configuration.html#a8611a6b9f477359b270734ec55206215',1,'leia_interlacer_debug_menu_configuration']]]
];
