var searchData=
[
  ['d3d11_0',['d3d11',['../structleia__interlacer__gui__configuration.html#a36012a74401121be689cfce38f7dfa2c',1,'leia_interlacer_gui_configuration']]],
  ['d3d12_1',['d3d12',['../structleia__interlacer__gui__configuration.html#a77a7727a52c71f99f008ce761bfb7daf',1,'leia_interlacer_gui_configuration']]],
  ['d_5fover_5fn_2',['d_over_n',['../structleia__device__config.html#a8d137bf64604fe3b16f3609423b47c5c',1,'leia_device_config']]],
  ['data_3',['data',['../structleia__asset__manager__buffer.html#a91a70b77df95bd8b0830b49a094c2acb',1,'leia_asset_manager_buffer::data'],['../structleia__float__slice.html#a57ba9c584cf7756552b7d4370e93395f',1,'leia_float_slice::data'],['../structleia__const__float__slice.html#a90f4df5a48f55b281e1b7293e9a4509c',1,'leia_const_float_slice::data'],['../structleia__slice.html#a735984d41155bc1032e09bece8f8d66d',1,'leia_slice::data'],['../structleia__image__desc.html#a96db82e580e46e24e2b39dd6c5bf7c21',1,'leia_image_desc::data']]],
  ['depth_4',['depth',['../structleia__headtracking__detected__face__eye.html#a845896541a0621f5fbd11f0d115ce463',1,'leia_headtracking_detected_face_eye']]],
  ['descriptorpool_5',['descriptorPool',['../structleia__interlacer__gui__configuration.html#ab3d7cf82d736cba3c1eae31ffeadf68f',1,'leia_interlacer_gui_configuration']]],
  ['detectedfaceindex_6',['detectedFaceIndex',['../structleia__headtracking__raw__face.html#ad9546ec5f1907eb528f46692b8edf125',1,'leia_headtracking_raw_face']]],
  ['device_7',['device',['../structleia__interlacer__gui__configuration.html#abd28c0efe479c17c1476917841e26ea8',1,'leia_interlacer_gui_configuration']]],
  ['devicecbvsrvheap_8',['deviceCbvSrvHeap',['../structleia__interlacer__gui__configuration.html#a80915f53b7953146354a02b06364cf04',1,'leia_interlacer_gui_configuration']]],
  ['devicecontext_9',['deviceContext',['../structleia__interlacer__gui__configuration.html#af643ce617f0e2e8aec271ea106b61f38',1,'leia_interlacer_gui_configuration']]],
  ['displaysizeinmm_10',['displaySizeInMm',['../structleia__device__config.html#ac7e81de586c485d64ae20d1d8540bc49',1,'leia_device_config']]],
  ['distortioncoeffs_11',['distortionCoeffs',['../structleia__camera__intrinsics.html#aad0175e51259dd9da4af7dc8f4dda8e6',1,'leia_camera_intrinsics']]],
  ['dotpitchinmm_12',['dotPitchInMM',['../structleia__device__config.html#ae582e238cb2a84c699b615123c1589ca',1,'leia_device_config']]],
  ['dummy_13',['dummy',['../structleia__asset__manager__resolve__context.html#a2bc054607a1d5d077801e7a89bc1e2e2',1,'leia_asset_manager_resolve_context']]]
];
