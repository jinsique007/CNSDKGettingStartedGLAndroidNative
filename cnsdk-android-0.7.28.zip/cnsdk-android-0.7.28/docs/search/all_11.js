var searchData=
[
  ['queue_0',['queue',['../structleia__interlacer__gui__configuration.html#a5a8dad25e9c0f7ce4ec646dbe5f4a2cc',1,'leia_interlacer_gui_configuration']]],
  ['queuefamily_1',['queueFamily',['../structleia__interlacer__gui__configuration.html#a4d045e54cbe335b513a1d4ab2aa762b7',1,'leia_interlacer_gui_configuration']]]
];
