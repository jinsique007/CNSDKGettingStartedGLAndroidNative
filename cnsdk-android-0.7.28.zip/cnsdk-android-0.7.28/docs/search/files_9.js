var searchData=
[
  ['platform_2eh_0',['platform.h',['../platform_8h.html',1,'']]]
];
