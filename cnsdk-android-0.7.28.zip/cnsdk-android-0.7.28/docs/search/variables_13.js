var searchData=
[
  ['theta_0',['theta',['../structleia__device__config.html#aadfc5c227ca658a29a59a0ce6fc15792',1,'leia_device_config']]],
  ['timestamp_1',['timestamp',['../structleia__headtracking__tracking__result.html#a450af1b278045fffef9c764cb90af310',1,'leia_headtracking_tracking_result']]],
  ['trackingpoint_2',['trackingPoint',['../structleia__headtracking__raw__face.html#acfb3d223d93af7cd7d98491c7388ac6f',1,'leia_headtracking_raw_face']]],
  ['type_3',['type',['../structleia__event.html#a277b0b24e4b4a7276526ff94a5fcfb77',1,'leia_event']]]
];
