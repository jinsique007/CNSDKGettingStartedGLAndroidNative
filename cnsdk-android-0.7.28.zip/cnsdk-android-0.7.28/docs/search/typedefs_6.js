var searchData=
[
  ['leia_5fevent_5flistener_5fcallback_0',['leia_event_listener_callback',['../event_center_8h.html#a166e83f3a2e08313195c99c94a8503a7',1,'eventCenter.h']]],
  ['leia_5ffree_5fuser_5fdata_5fcb_1',['leia_free_user_data_cb',['../common_2types_8h.html#abeace80de2c834de8b918c92da6a055f',1,'types.h']]],
  ['leia_5fheadtracking_5fface_5fidx_2',['leia_headtracking_face_idx',['../head_tracking_2common_2types_8h.html#a7e74491acf38f5be270172cfbfeed4ed',1,'types.h']]],
  ['leia_5fheadtracking_5fon_5fframe_5fcb_3',['leia_headtracking_on_frame_cb',['../frame_listener_8h.html#afe71baf6ded6aa97ad082e762750f402',1,'frameListener.h']]],
  ['leia_5finterlacer_5fgui_5fsurface_4',['leia_interlacer_gui_surface',['../core_8types_8h.html#a0f5d54f5d49a3393a86b6dc7dfc6317e',1,'core.types.h']]],
  ['leia_5flog_5flevel_5',['leia_log_level',['../log_8h.html#ab62d1469553f3f76ce258f2bdb5f9dd1',1,'log.h']]]
];
