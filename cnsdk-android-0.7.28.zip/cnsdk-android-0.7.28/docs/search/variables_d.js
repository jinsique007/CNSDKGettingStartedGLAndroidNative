var searchData=
[
  ['n_0',['n',['../structleia__device__config.html#a7f72c6c4ce2ae87fa6fe5f6f22cd9d67',1,'leia_device_config']]],
  ['num_5ffaces_1',['num_faces',['../structleia__headtracking__tracking__result.html#a443d8852f2568185527560d12b231b40',1,'leia_headtracking_tracking_result']]],
  ['numfaces_2',['numFaces',['../structleia__headtracking__raw__faces.html#a523d3dc0299fc8921db1c26cc908f084',1,'leia_headtracking_raw_faces::numFaces'],['../structleia__headtracking__detected__faces.html#a523d3dc0299fc8921db1c26cc908f084',1,'leia_headtracking_detected_faces::numFaces']]],
  ['numframesinflight_3',['numFramesInFlight',['../structleia__interlacer__gui__configuration.html#ab6a1fcff2233604611f0b91e1d7c19fd',1,'leia_interlacer_gui_configuration']]],
  ['numviews_4',['numViews',['../structleia__device__config.html#a26bdd0e4c2725f789a2c01e584d296eb',1,'leia_device_config']]]
];
