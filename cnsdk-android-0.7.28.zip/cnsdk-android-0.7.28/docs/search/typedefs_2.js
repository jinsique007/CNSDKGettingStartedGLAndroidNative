var searchData=
[
  ['facedetectorbackend_0',['FaceDetectorBackend',['../namespaceleia.html#af22c51fbae7d6d9390e5820a38646bad',1,'leia']]],
  ['facedetectorconfig_1',['FaceDetectorConfig',['../namespaceleia.html#a57b25746a254c9f927fcc4db7e7255ba',1,'leia']]],
  ['facedetectorinputtype_2',['FaceDetectorInputType',['../namespaceleia.html#a901164e733020444a1f12fc8bfe674b2',1,'leia']]],
  ['facetrackingframe_3',['FaceTrackingFrame',['../namespaceleia_1_1sdk.html#a58e2750379ad2316d1f119251f4bed05',1,'leia::sdk']]],
  ['facetrackingframelistener_4',['FaceTrackingFrameListener',['../namespaceleia_1_1sdk.html#a7ecf079ea69b24d0ddf4ae74db326961',1,'leia::sdk']]],
  ['facetrackingruntimetype_5',['FaceTrackingRuntimeType',['../namespaceleia.html#a3f3fa4a6553a8e3563bd86eca87fe4a9',1,'leia']]],
  ['fitmode_6',['FitMode',['../namespaceleia_1_1sdk.html#afd1e2f04865dfcd89a9dd84bbfa9998e',1,'leia::sdk::FitMode'],['../namespaceleia.html#afd1e2f04865dfcd89a9dd84bbfa9998e',1,'leia::FitMode']]],
  ['floatslice_7',['FloatSlice',['../namespaceleia.html#a4b2aa456da7e9e0bb3b544bb4c1a9fcd',1,'leia']]]
];
