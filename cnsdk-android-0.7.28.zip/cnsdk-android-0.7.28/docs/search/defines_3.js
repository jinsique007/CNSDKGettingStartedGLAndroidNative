var searchData=
[
  ['end_5fcapi_5fdecl_0',['END_CAPI_DECL',['../defines_8h.html#adaf8dd45b02ca5c6ad81d0f365ccdebd',1,'defines.h']]]
];
