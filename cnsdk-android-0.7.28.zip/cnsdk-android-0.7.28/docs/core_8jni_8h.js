var core_8jni_8h =
[
    [ "leia_core_from_java", "core_8jni_8h.html#a1b1c762c15b7d0b516de7efc620074cd", null ]
];