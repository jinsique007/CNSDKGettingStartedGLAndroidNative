var platform_8h =
[
    [ "leia_platform_on_library_load", "platform_8h.html#ac168da76313a7f6a4b911f6cdb7a84d5", null ],
    [ "leia_platform_on_library_unload", "platform_8h.html#ab39180b5cde4ef056423ad194a97944e", null ]
];