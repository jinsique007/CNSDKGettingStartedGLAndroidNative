var modules =
[
    [ "Core", "group__core.html", "group__core" ]
];