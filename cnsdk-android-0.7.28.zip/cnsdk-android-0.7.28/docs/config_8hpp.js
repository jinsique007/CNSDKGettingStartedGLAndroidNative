var config_8hpp =
[
    [ "IMGUI_API", "config_8hpp.html#a43829975e84e45d1149597467a14bbf5", null ],
    [ "GImGui", "config_8hpp.html#a06085cd7dd75726d4a4810add58576e9", null ],
    [ "g_ImGuiTLS", "config_8hpp.html#ae513721ecd2290f4d42dda251fbfa149", null ]
];