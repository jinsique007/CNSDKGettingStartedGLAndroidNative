var structleia__interlacer__gui__input__state =
[
    [ "wantCaptureInput", "structleia__interlacer__gui__input__state.html#ad959da01ce66d2d3c5efd8e1daa94b65", null ],
    [ "wantCaptureMouse", "structleia__interlacer__gui__input__state.html#a6af65f4205c61d57314137a0657898cc", null ],
    [ "wantCaptureKeyboard", "structleia__interlacer__gui__input__state.html#a1abac2ee41d394832c782f1263c9464c", null ],
    [ "wantTextInput", "structleia__interlacer__gui__input__state.html#a97ca6547d0cc7cccacb6bc120409b31e", null ]
];