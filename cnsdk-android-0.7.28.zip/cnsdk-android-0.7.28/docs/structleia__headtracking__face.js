var structleia__headtracking__face =
[
    [ "point", "structleia__headtracking__face.html#a5d7996f088a1573f1b56ed6ac3f0f827", null ],
    [ "angle", "structleia__headtracking__face.html#a95b2fc5dca3c574af547eed7d1d0a4a2", null ],
    [ "rawFaceIndex", "structleia__headtracking__face.html#a51dc17839177a2d076f0a426c5da3142", null ]
];