var log_8h =
[
    [ "leia_log_level", "log_8h.html#ab62d1469553f3f76ce258f2bdb5f9dd1", null ],
    [ "leia_log_level_to_string", "log_8h.html#aa3614221ffd4a5357089cef5d3e70bae", null ]
];