var structleia__event__error =
[
    [ "message", "structleia__event__error.html#a254bf0858da09c96a48daf64404eb4f8", null ],
    [ "code", "structleia__event__error.html#a671b75da3c5ab5860a87dffc9e1c502a", null ]
];