var structleia__headtracking__moving__point =
[
    [ "pos", "structleia__headtracking__moving__point.html#a2a529016ee03846e47ccf4fec7f263e3", null ],
    [ "vel", "structleia__headtracking__moving__point.html#ab19ddd00d8fe9dac8100a942e41dec4a", null ]
];