var structleia__source__location =
[
    [ "filename", "structleia__source__location.html#a7efa5e9c7494c7d4586359300221aa5d", null ],
    [ "funcname", "structleia__source__location.html#acfe7fa99b3c04a17dcf3856bb2394a6b", null ],
    [ "line", "structleia__source__location.html#a41ebd28ef1d7c6ade45642cb6acc1039", null ]
];