var frame_8h =
[
    [ "leia_headtracking_raw_faces", "structleia__headtracking__raw__faces.html", "structleia__headtracking__raw__faces" ],
    [ "leia_headtracking_detected_faces", "structleia__headtracking__detected__faces.html", "structleia__headtracking__detected__faces" ],
    [ "leia_headtracking_frame_profiling", "structleia__headtracking__frame__profiling.html", "structleia__headtracking__frame__profiling" ],
    [ "leia_headtracking_frame_get_tracking_result", "frame_8h.html#a9ce021f45316073ed8db02aeb93a6890", null ],
    [ "leia_headtracking_frame_get_raw_faces", "frame_8h.html#a081e6e343dde23b20c40dddb8672591e", null ],
    [ "leia_headtracking_frame_get_detected_faces", "frame_8h.html#af581945f813f17025d1d0c46952b2110", null ],
    [ "leia_headtracking_frame_get_profiling", "frame_8h.html#a8e8f3bccb25c053c186da48e2846e77c", null ],
    [ "leia_headtracking_frame_release", "frame_8h.html#a376cbb2d1b136cfb2930a0d891e91794", null ]
];