var structleia__headtracking__detected__face =
[
    [ "eyes", "structleia__headtracking__detected__face.html#a88fff94e477a6c43611a1939604670cd", null ],
    [ "posePosition", "structleia__headtracking__detected__face.html#a22a9f413a480ae2792d37365076233ec", null ],
    [ "poseAngle", "structleia__headtracking__detected__face.html#a4d25a82a52534f20162af85aee6780b9", null ],
    [ "id", "structleia__headtracking__detected__face.html#abaabdc509cdaba7df9f56c6c76f3ae19", null ]
];