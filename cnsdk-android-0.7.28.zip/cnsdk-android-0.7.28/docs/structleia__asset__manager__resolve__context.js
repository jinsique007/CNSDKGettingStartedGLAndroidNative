var structleia__asset__manager__resolve__context =
[
    [ "dummy", "structleia__asset__manager__resolve__context.html#a2bc054607a1d5d077801e7a89bc1e2e2", null ]
];