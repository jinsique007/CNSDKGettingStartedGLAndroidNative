var structleia__const__float__slice =
[
    [ "data", "structleia__const__float__slice.html#a90f4df5a48f55b281e1b7293e9a4509c", null ],
    [ "length", "structleia__const__float__slice.html#a5ae5048776b1de2d7dce124f78dc300f", null ]
];