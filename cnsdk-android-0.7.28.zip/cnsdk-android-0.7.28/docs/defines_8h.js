var defines_8h =
[
    [ "LEIA_EXPORT", "defines_8h.html#adb10c7d8e9e29dd7e2388f4bae04140b", null ],
    [ "LEIA_IMPORT", "defines_8h.html#ac4206a219509db8f5d0f0a2b0ab54d28", null ],
    [ "LEIA_HIDDEN", "defines_8h.html#ab86f6b6e1abc2eb2931e6cdfb6ec49e2", null ],
    [ "LEIA_CLASS_EXPORT", "defines_8h.html#a8cddee82bdc3ccf2bc96fb78e5406617", null ],
    [ "LEIA_CLASS_IMPORT", "defines_8h.html#aefec62fa2e5f1692a2e371164fc51cea", null ],
    [ "LEIA_DEPRECATED", "defines_8h.html#a8bfc2a0c2e1885baf453a8f923a8b57a", null ],
    [ "LEIA_FORCE_INLINE", "defines_8h.html#a580ea19e1cdd8e72fc6943a64346b275", null ],
    [ "LEIA_FUNCTION", "defines_8h.html#aedef9975846432e86e65be9bd08554f2", null ],
    [ "BEGIN_CAPI_DECL", "defines_8h.html#af92e8a404827fb3c036bbb77ceb78b4a", null ],
    [ "END_CAPI_DECL", "defines_8h.html#adaf8dd45b02ca5c6ad81d0f365ccdebd", null ],
    [ "LEIA_NODISCARD", "defines_8h.html#aba7c8d958c54cc7976501b020023263b", null ],
    [ "_LEIA_STRINGIZE", "defines_8h.html#a63c0765d76c688378749faa58e1fd735", null ],
    [ "LEIA_STRINGIZE", "defines_8h.html#a655b4b19420755007fa9545127e00e8c", null ],
    [ "LEIA_X32", "defines_8h.html#a23c861cff17e5ec74534251088059bc8", null ],
    [ "NONOWNING", "defines_8h.html#ae154d5ab9b8400379c22361f6d7acad0", null ],
    [ "OWNING", "defines_8h.html#ad18bf199ec565ac3daf1a572e5ae6a7b", null ],
    [ "LEIA_USE_OPENGL", "defines_8h.html#a77e73c9173b6be59f08203810220c713", null ]
];