var structleia__asset__manager__buffer =
[
    [ "size", "structleia__asset__manager__buffer.html#af931a8871310b4dad23f0f0b0f623560", null ],
    [ "data", "structleia__asset__manager__buffer.html#a91a70b77df95bd8b0830b49a094c2acb", null ]
];