var structleia__interlacer__single__view__mode__listener =
[
    [ "userData", "structleia__interlacer__single__view__mode__listener.html#a2e294dd14122c554baa0665072b4ca7a", null ],
    [ "onSingleViewModeChange", "structleia__interlacer__single__view__mode__listener.html#ace4a506b6089ad509c0b980f0cc02879", null ]
];