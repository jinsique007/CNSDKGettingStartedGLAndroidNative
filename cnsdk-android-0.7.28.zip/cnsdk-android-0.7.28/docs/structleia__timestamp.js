var structleia__timestamp =
[
    [ "ms", "structleia__timestamp.html#ac0c30c1e98c242e3e868c424886912e5", null ],
    [ "space", "structleia__timestamp.html#a1dda1d68d2f8ce25217273c2e25709c7", null ]
];