var head_tracking_2common_2types_8h =
[
    [ "leia_headtracking_moving_point", "structleia__headtracking__moving__point.html", "structleia__headtracking__moving__point" ],
    [ "leia_headtracking_face", "structleia__headtracking__face.html", "structleia__headtracking__face" ],
    [ "leia_headtracking_raw_face", "structleia__headtracking__raw__face.html", "structleia__headtracking__raw__face" ],
    [ "leia_headtracking_detected_face_eye", "structleia__headtracking__detected__face__eye.html", "structleia__headtracking__detected__face__eye" ],
    [ "leia_headtracking_detected_face", "structleia__headtracking__detected__face.html", "structleia__headtracking__detected__face" ],
    [ "leia_headtracking_tracking_result", "structleia__headtracking__tracking__result.html", "structleia__headtracking__tracking__result" ],
    [ "LEIA_HEADTRACKING_MAX_NUM_FACES", "head_tracking_2common_2types_8h.html#a0c2f1c6288ffe759dcaf441a0122ec80", null ],
    [ "leia_headtracking_face_idx", "head_tracking_2common_2types_8h.html#a7e74491acf38f5be270172cfbfeed4ed", null ],
    [ "leia_headtracking_eye_idx", "head_tracking_2common_2types_8h.html#a356c35cd6d8017c69394f25a027804e0", [
      [ "kLeiaHeadTrackingRightEyeIdx", "head_tracking_2common_2types_8h.html#a356c35cd6d8017c69394f25a027804e0a5d67b032e45dedc36ae004b0335d99db", null ],
      [ "kLeiaHeadTrackingLeftEyeIdx", "head_tracking_2common_2types_8h.html#a356c35cd6d8017c69394f25a027804e0a77378404f1bae6841e537ccdd73bd735", null ],
      [ "kLeiaHeadTrackingNumEyes", "head_tracking_2common_2types_8h.html#a356c35cd6d8017c69394f25a027804e0a6ee8d2ef89822a732d8e2428b4594b3a", null ]
    ] ],
    [ "leia_headtracking_status", "head_tracking_2common_2types_8h.html#a8218beff5f2a4db3f0a519813fb672b8", null ]
];