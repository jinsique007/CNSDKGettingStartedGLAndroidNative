var structleia__headtracking__tracking__result =
[
    [ "num_faces", "structleia__headtracking__tracking__result.html#a443d8852f2568185527560d12b231b40", null ],
    [ "faces", "structleia__headtracking__tracking__result.html#a793bd0365ceebe1544923ccf4083f09c", null ],
    [ "timestamp", "structleia__headtracking__tracking__result.html#a450af1b278045fffef9c764cb90af310", null ],
    [ "jumpFlag", "structleia__headtracking__tracking__result.html#a85c3cc94b68a21d4563017b4e0244829", null ]
];