var structleia__mat4 =
[
    [ "col", "structleia__mat4.html#a48bd493d2ccc433a5e69c1dcfa1f7606", null ],
    [ "m", "structleia__mat4.html#a68147cce833d98b698183d68629e38d5", null ]
];