var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "b", "globals_b.html", null ],
    [ "c", "globals_c.html", null ],
    [ "e", "globals_e.html", null ],
    [ "g", "globals_g.html", null ],
    [ "i", "globals_i.html", null ],
    [ "j", "globals_j.html", null ],
    [ "k", "globals_k.html", null ],
    [ "l", "globals_l.html", null ],
    [ "n", "globals_n.html", null ],
    [ "o", "globals_o.html", null ],
    [ "v", "globals_v.html", null ]
];