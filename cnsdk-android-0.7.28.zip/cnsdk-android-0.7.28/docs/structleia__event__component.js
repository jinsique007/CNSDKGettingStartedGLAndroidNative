var structleia__event__component =
[
    [ "id", "structleia__event__component.html#a86d453ff33ef64c0eea4f75d008116f4", null ],
    [ "code", "structleia__event__component.html#af270ae14bf63d32c77ae1a03ad8891b9", null ],
    [ "payload", "structleia__event__component.html#a40f7bdac227a665c6f751055f94af57f", null ]
];