var structleia__float__slice =
[
    [ "data", "structleia__float__slice.html#a57ba9c584cf7756552b7d4370e93395f", null ],
    [ "length", "structleia__float__slice.html#a5ae5048776b1de2d7dce124f78dc300f", null ]
];