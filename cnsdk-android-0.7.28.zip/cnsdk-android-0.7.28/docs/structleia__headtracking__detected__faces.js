var structleia__headtracking__detected__faces =
[
    [ "numFaces", "structleia__headtracking__detected__faces.html#a523d3dc0299fc8921db1c26cc908f084", null ],
    [ "faces", "structleia__headtracking__detected__faces.html#a2f794e7a927c3ca4d27d94fcf18849b1", null ]
];