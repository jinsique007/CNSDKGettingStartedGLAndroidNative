var structleia__headtracking__frame__profiling =
[
    [ "cameraExposureTime", "structleia__headtracking__frame__profiling.html#ada97b18d78834186af7703f3c22b19d3", null ],
    [ "faceDetectorStartTime", "structleia__headtracking__frame__profiling.html#a7cc8fbdf0024c20f41d31dfff117fb49", null ],
    [ "faceDetectorEndTime", "structleia__headtracking__frame__profiling.html#afb41cb8a70d9f02dc77f2fe6a03f9e41", null ],
    [ "apiTimestamp", "structleia__headtracking__frame__profiling.html#a66f35b27d0fab8af77ae3adb4d3170dc", null ]
];