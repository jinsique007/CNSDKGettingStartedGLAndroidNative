var classleia_1_1sdk_1_1_core_init_configuration =
[
    [ "CoreInitConfiguration", "classleia_1_1sdk_1_1_core_init_configuration.html#ad80ff7d7f4b9feaadfd8b08926ced015", null ],
    [ "~CoreInitConfiguration", "classleia_1_1sdk_1_1_core_init_configuration.html#aa3cc6141b0cefb340bd93f45fe68b951", null ],
    [ "CoreInitConfiguration", "classleia_1_1sdk_1_1_core_init_configuration.html#a44a34aa30d65baa9564051434f96ebf2", null ],
    [ "CoreInitConfiguration", "classleia_1_1sdk_1_1_core_init_configuration.html#af1ef8121df093410e2d9ce6ec8a5f27d", null ],
    [ "operator=", "classleia_1_1sdk_1_1_core_init_configuration.html#afb43b9677cc778e0061777bad0a26a5a", null ],
    [ "operator=", "classleia_1_1sdk_1_1_core_init_configuration.html#aecae6a558009f28adfae15da5e090495", null ],
    [ "UseOldRenderer", "classleia_1_1sdk_1_1_core_init_configuration.html#a6e6fcdcac96248aa9d314063f566b9c1", null ],
    [ "SetEnableValidation", "classleia_1_1sdk_1_1_core_init_configuration.html#abd903b479e89fcc9f6020917e25a8a1d", null ],
    [ "SetPlatformAndroidHandle", "classleia_1_1sdk_1_1_core_init_configuration.html#ab23487897ff2da56e229d43c97d15b12", null ],
    [ "SetPlatformAndroidJavaVM", "classleia_1_1sdk_1_1_core_init_configuration.html#a81cb5f3f9043d14db3e84773fe67fba5", null ],
    [ "SetPlatformLogLevel", "classleia_1_1sdk_1_1_core_init_configuration.html#a005ba06f0bfda16a448c2582d2640037", null ],
    [ "SetFaceTrackingSharedCameraSink", "classleia_1_1sdk_1_1_core_init_configuration.html#a8ba82e7986b74956638d48486884ac04", null ],
    [ "SetFaceTrackingRuntime", "classleia_1_1sdk_1_1_core_init_configuration.html#a45a945d2acb2cd2ee2a72005016b349d", null ],
    [ "SetFaceTrackingEnable", "classleia_1_1sdk_1_1_core_init_configuration.html#a5b304f1884aa46c36ad843c414854cfd", null ],
    [ "SetFaceTrackingStart", "classleia_1_1sdk_1_1_core_init_configuration.html#a742fe4c0010df4f158e489155965975d", null ],
    [ "SetFaceTrackingCheckPermission", "classleia_1_1sdk_1_1_core_init_configuration.html#a50739fc79062e700b929eb2b9eb988ce", null ],
    [ "SetFaceTrackingPermissionDialogKillProcess", "classleia_1_1sdk_1_1_core_init_configuration.html#aaebb2387b5dd62b9d1dbe816e92a1554", null ],
    [ "SetFaceTrackingServerLogLevel", "classleia_1_1sdk_1_1_core_init_configuration.html#a2a5476672b7b24f2002572c8c77d33e3", null ],
    [ "GetHandle", "classleia_1_1sdk_1_1_core_init_configuration.html#af016fc09124a31e43b9fd1e35a5219ed", null ]
];