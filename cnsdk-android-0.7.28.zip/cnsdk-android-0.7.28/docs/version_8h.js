var version_8h =
[
    [ "CNSDK_VERSION", "version_8h.html#af4ec833d6d283013bbae6067e586b963", null ],
    [ "CNSDK_MAJOR_VERSION", "version_8h.html#a9926f3a063a23b9bbbb409c3dcc31607", null ],
    [ "CNSDK_MINOR_VERSION", "version_8h.html#a8762cb257a2a9a93963f8e45ffdd825c", null ],
    [ "CNSDK_PATCH_VERSION", "version_8h.html#a2beea5a2a6bf15fc1a36c94a0f453162", null ],
    [ "leia_get_git_refspec", "version_8h.html#a4707b5e2e48acdeb82f21698082e67dc", null ],
    [ "leia_get_git_sha1", "version_8h.html#ab9726d7a6eaa689d2492b0885e3eaa0d", null ],
    [ "leia_get_version", "version_8h.html#a8f0192f63d6c8f5fd23cdc5f92a2359f", null ]
];