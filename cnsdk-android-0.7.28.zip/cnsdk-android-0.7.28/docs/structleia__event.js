var structleia__event =
[
    [ "type", "structleia__event.html#a277b0b24e4b4a7276526ff94a5fcfb77", null ],
    [ "log", "structleia__event.html#a73c475da08fc0b66ab98474cd7209f68", null ],
    [ "error", "structleia__event.html#a2f09116f345498f74ff01a947cb78dce", null ],
    [ "component", "structleia__event.html#a709f8ccafebb4692bd8909462ed05d98", null ],
    [ "v", "structleia__event.html#ab6ba54c159129b751a87f4263ba268d7", null ]
];