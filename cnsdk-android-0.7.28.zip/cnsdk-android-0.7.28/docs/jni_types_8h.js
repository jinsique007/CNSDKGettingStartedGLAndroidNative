var jni_types_8h =
[
    [ "jobject", "jni_types_8h.html#a24647d2a2f02c39f6338c2c6ce4c1004", null ],
    [ "jint", "jni_types_8h.html#a36d2d2d6848d7f576b7f8875f95efd1e", null ],
    [ "C_JNIEnv", "jni_types_8h.html#a7ccf81ddaaa811d5fc307a2a5edca132", null ],
    [ "JNIEnv", "jni_types_8h.html#ade02b8c45188da2bfcfa8072214d0e1c", null ],
    [ "JavaVM", "jni_types_8h.html#abc5c833ca98abdc33d0567b174e2e132", null ]
];