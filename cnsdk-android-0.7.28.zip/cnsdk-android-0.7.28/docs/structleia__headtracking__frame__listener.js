var structleia__headtracking__frame__listener =
[
    [ "leia_headtracking_frame_listener_release", "structleia__headtracking__frame__listener.html#ae1a3570e361a4d763cd33181c2a6e0b6", null ],
    [ "leia_headtracking_frame_listener_alloc", "structleia__headtracking__frame__listener.html#ab1b020ad8e8397b4f0254e4af42c52bb", null ]
];