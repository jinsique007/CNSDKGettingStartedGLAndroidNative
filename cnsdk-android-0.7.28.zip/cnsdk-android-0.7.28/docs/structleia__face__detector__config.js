var structleia__face__detector__config =
[
    [ "backend", "structleia__face__detector__config.html#a14eff29a296235b2f50a5710d55ee27a", null ],
    [ "inputType", "structleia__face__detector__config.html#adafb0bca2fe08bc75a9fadb0a0a3a765", null ]
];